export interface Candidate {
  fullname: string;
  email: string;
  mobile: string;
  password: string;
}
